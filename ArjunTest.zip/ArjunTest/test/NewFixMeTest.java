/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import fix.me.im.broken.CSVReader;
import fix.me.im.broken.PersonInfo;
import java.security.KeyStore.Entry;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.testng.Assert;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author Arjun
 */
public class NewFixMeTest {
    
    public NewFixMeTest() {
    }
    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
     @Test
     public void test() 
     { 
        PersonInfo p=new PersonInfo();
      
        p.setFirstName("Tony");
        p.setLastName("88888");
        p.setAge(48);
        p.setZipcode("11002");
        List<PersonInfo> l=new ArrayList<PersonInfo>();
        l.add(p);
         CSVReader r= new CSVReader();
         
          Map m= r.readCSV("C:\\Users\\Arjun\\Documents\\TestCSV.csv");
         ArrayList<PersonInfo> l2= (ArrayList<PersonInfo>)m.get("11002");
       
          for(PersonInfo pe:l2)
          {
              System.out.println(pe.getFirstName()+" "+pe.getLastName()+" "+pe.getAge()+" "+pe.getZipcode());
          }
      for(PersonInfo per:l)
      {
       System.out.println(per.getFirstName()+" "+per.getLastName()+" "+per.getAge()+" "+per.getZipcode());
      }
      //  r.printInfo(m);
        System.out.println(l.equals(l2));
   //    Assert.assertTrue(l.equals(l2));
        
     }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }
}